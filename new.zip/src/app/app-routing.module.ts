import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReportConfigurationComponent } from './report-configuration/report-configuration.component';
import { StaticDataComponent } from './static-data/static-data.component';
import { ReportConfigurationsComponent } from './report-configurations/report-configurations.component';
import { TestComponent } from './test/test.component';

const routes: Routes = [
  {path: '',         pathMatch: 'full',  component : ReportConfigurationComponent},
  {path: 'reportConfig', component: ReportConfigurationComponent},
  {path: 'staticData', component: StaticDataComponent},
  {path: 'report', component: ReportConfigurationsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

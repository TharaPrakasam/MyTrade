import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportConfigurationsComponent } from './report-configurations.component';

describe('ReportConfigurationsComponent', () => {
  let component: ReportConfigurationsComponent;
  let fixture: ComponentFixture<ReportConfigurationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportConfigurationsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReportConfigurationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, ViewEncapsulation } from '@angular/core';
import { SnackbarService } from '../shared/services/snackbar.service';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from "@angular/material/dialog";
import { ModelPopupComponent } from '../model-popup/model-popup.component';
import {MatCalendarCellClassFunction} from '@angular/material/datepicker';

@Component({
  selector: 'app-client-report',
  templateUrl: './client-report.component.html',
  styleUrls: ['./client-report.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class ClientReportComponent {

  public innerHeight:any;
  public innerHeight1:any;
  public btnHeight: any;
  public fxFlexForCol1: any = 50;
  public fxFlexForCol2: any = 50;
  public isHideFirstCol: boolean = true;
  matDialogRef: MatDialogRef<ModelPopupComponent> | undefined;
  rowData = [
    // { make: "Toyota", model: "Celica", price: 35000 },
    // { make: "Ford", model: "Mondeo", price: 32000 },
    // { make: "Porsche", model: "Boxter", price: 72000 }
  ];
  columnDefs = [ { field: "", headerCheckboxSelection: true, width:'100px' }, 
  { field: "File Name", width:'300px'  }, 
  { field: "File Type", width:'300px'  }, 
  { field: "Date / Time", width:'300px' },
  ];

  columnDefs1 = [  
  { field: "QC ID", width:'100px'  }, 
  { field: "Key", width:'100px'  }, 
  { field: "Column Name", width:'150px' },
  { field: "Version", width:'100px' },
  { field: "State", width:'250px' },
  { field: "Failed Date", width:'250px' },
  { field: "Correction ID", width:'250px' },
  { field: "Correction Info", width:'250px' },
  ];

  columnDefs2 = [
    { field: "Fund Nav Key", width:'250px'  }, 
  { field: "Fund Validation Key", width:'250px'  }, 
  { field: "Validation Date", width:'250px' },
    { field: "Version", width:'250px' },
  { field: "State", width:'250px' },
  ]
  rowData1 = [
    // {origin:'',modification: 'Test',user:'G1-45124',Date:'27/03/2024 07:00:45'}
  ];

  columnHeader = [
    { field: "Fund Nav Key" }, { field: "Fund IDs" }, { field: "Nav Date" }, { field: "Validation Date"},
    { field: "Version"},{ field: "Approve"}
  ]

  columnHeader1 = [
    { field: "", headerCheckboxSelection: true, width:'100px' }, 
  { field: "Config Id", width:'200px'  }, 
  { field: "Config Name", width:'200px'  }, 
  { field: "Fund Id", width:'200px' },
  { field: "Domicile", width:'150px' },
  { field: "Updated By", width:'150px' },
  { field: "Updated Date", width:'150px' },
  { field: "Action", width:'150px' }];

  dateClass: MatCalendarCellClassFunction<Date> = (cellDate, view) => {
    // Only highligh dates inside the month view.
    if (view === 'month') {
      const date = cellDate.getDate();

      // Highlight the 1st and 20th day of each month.
      return date === 1 || date === 20 ? 'example-custom-date-class' : '';
    }

    return '';
  };

  constructor(
    public snackBarService : SnackbarService,
    private matDialog: MatDialog
  ) {
    this.innerHeight = window.innerHeight - 75;
    this.innerHeight1 = window.innerHeight - 220;

    this.btnHeight = window.innerHeight - 560;
  }

  ngOnInit() {


    
  }


  openDialog() {
    this.matDialogRef = this.matDialog.open(ModelPopupComponent, {
      // data: { name: this.name },
      disableClose: true,
      height: '30%',
      width: '30%'
    });
  }

}

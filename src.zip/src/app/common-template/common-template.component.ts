import { Component } from '@angular/core';
import { SnackbarService } from '../shared/services/snackbar.service';


@Component({
  selector: 'app-common-template',
  templateUrl: './common-template.component.html',
  styleUrls: ['./common-template.component.css']
})
export class CommonTemplateComponent {

  public innerHeight:any;
  public btnHeight: any;
  public fxFlexForCol1: any = 100;
  public fxFlexForCol2: any = 100;
  public isHideFirstCol: boolean = true;
  rowData = [
    // { make: "Toyota", model: "Celica", price: 35000 },
    // { make: "Ford", model: "Mondeo", price: 32000 },
    // { make: "Porsche", model: "Boxter", price: 72000 }
  ];
  columnDefs = [ { field: "Configurations", width:'100px' }, { field: "Fund id", width:'100px'  }, { field: "Domical", width:'100px'  }, 
  { field: "Chennel", width:'100px' },
  { field: "Archive", width:'100px' },{ field: "Active", width:'100px' },{ field: "Favorite", width:'100px' }];

  rowData1 = [
    // {origin:'',modification: 'Test',user:'G1-45124',Date:'27/03/2024 07:00:45'}
  ];
  columnDefs1 = [ { field: "Configurations", headerCheckboxSelection: true,width:'100px' }, { field: "Domicle", width:'100px'  }, { field: "Fund ID", width:'100px'  }, 
  { field: "Managers", width:'100px' },
  { field: "Fund Name", width:'100px' },{ field: "Frequency", width:'100px' },{ field: "Approval Ratings", width:'100px' }];
  columnHeader = [
    { field: "Configurations" }, { field: "Fund IDs" }, { field: "Domical" }, { field: "Chennel"},
    { field: "Archive"},{ field: "Active"},{ field: "Favorite"}
  ]

  constructor(
    public snackBarService : SnackbarService
  ) {
    this.innerHeight = window.innerHeight - 70;
    this.btnHeight = window.innerHeight - 560;
  }

  ngOnInit() {


    
  }


  fullscreen() {
    console.log(this.fxFlexForCol1)
    console.log(this.fxFlexForCol2)
    if(this.fxFlexForCol1 == 50) {
      this.isHideFirstCol = false;
      this.fxFlexForCol1= 0;
      this.fxFlexForCol2 = 100;
    } 
    else {
      this.isHideFirstCol = true;
      this.fxFlexForCol1= 50;
      this.fxFlexForCol2 = 50;
    }  
  }
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent {

  public innerHeight:any;
  public btnHeight: any;
  columnDefs = [{ field: "Client Name" }, { field: "Config Type" }, { field: "Created By" }, { field: "Configuration Date"}];

  rowData = [
    // { make: "Toyota", model: "Celica", price: 35000 },
    // { make: "Ford", model: "Mondeo", price: 32000 },
    // { make: "Porsche", model: "Boxter", price: 72000 }
  ];

  constructor() {
    this.innerHeight = window.innerHeight - 90;
    this.btnHeight = window.innerHeight - 560;

  }

  ngOnInit() {
    console.log(window.innerHeight);
  }

}
